<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Mahasiswa</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <h1>Data Mahasiswa</h1>

    <a href="<?php echo e(route('mahasiswa.create')); ?>" class="btn btn-tambah">+ Tambah Data</a>

    <?php if(session('success')): ?>
        <div class="alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIM</th>
                <th>Jurusan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($mhs->nama); ?></td>
                <td><?php echo e($mhs->nim); ?></td>
                <td><?php echo e($mhs->jurusan); ?></td>
                <td>
                    <a href="<?php echo e(route('mahasiswa.edit', $mhs->id)); ?>" class="btn btn-edit">Edit</a>
                    <form action="<?php echo e(route('mahasiswa.destroy', $mhs->id)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-hapus" onclick="return confirm('Yakin hapus?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH D:\laragon\www\Aplikasi_CRUD\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>