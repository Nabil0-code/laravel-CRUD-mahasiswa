<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Data Mahasiswa</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Tambah Data Mahasiswa</h1>

        <form action="<?php echo e(route('mahasiswa.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nama" required>
            </div>

            <div class="form-group">
                <label>NIM</label>
                <input type="text" name="nim" required>
            </div>

            <div class="form-group">
                <label>Jurusan</label>
                <input type="text" name="jurusan" required>
            </div>

            <button type="submit" class="btn btn-save">Simpan</button>
            <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-back">Kembali</a>
        </form>
    </div>
</body>
</html>
<?php /**PATH D:\laragon\www\Aplikasi_CRUD\resources\views/mahasiswa/create.blade.php ENDPATH**/ ?>