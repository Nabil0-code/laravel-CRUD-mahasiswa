<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Mahasiswa</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Edit Data Mahasiswa</h1>

        <form action="<?php echo e(route('mahasiswa.update', $mahasiswa->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nama" value="<?php echo e($mahasiswa->nama); ?>" required>
            </div>

            <div class="form-group">
                <label>NIM</label>
                <input type="text" name="nim" value="<?php echo e($mahasiswa->nim); ?>" required>
            </div>

            <div class="form-group">
                <label>Jurusan</label>
                <input type="text" name="jurusan" value="<?php echo e($mahasiswa->jurusan); ?>" required>
            </div>

            <button type="submit" class="btn btn-update">Perbarui</button>
            <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-back">Kembali</a>
        </form>
    </div>
</body>
</html>
<?php /**PATH D:\laragon\www\Aplikasi_CRUD\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>